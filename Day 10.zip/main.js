//Quetsion 1:using textcontent by  getElementById 
const sampleElement = document.getElementById("sample1");

  console.log(sampleElement); 
  console.log(sampleElement.textContent);
//using getElementById 
  const techElement =document.getElementById("techCompanies")

  console.log(techElement);
  //2.2 using querySelector 
  const techElement2 =document.querySelector("#techCompanies")
  console.log(techElement2)
 //2.3 count the total element list under ul using querySelectorAll
 const techElement3 =document.querySelectorAll("#techCompanies li")
 console.log(techElement3.length)
  //2.4 select element using classname
  const techElement4=document.querySelectorAll(".red")
  console.log(techElement4)
  const techElement5=document.getElementsByClassName("red")
  console.log(techElement5)
  //2.5 creat new element
  const newElement=document.createElement("li")
  newElement.textContent=("Facebook")
  console.log(newElement)
  newElement.className=("blue")
  console.log(newElement)
  //2.6 append element
  const appendElement=document.querySelector(".yellow")
  appendElement.insertAdjacentElement("afterend",newElement)
 //2.7:Count blue
  const blueCount=document.querySelectorAll(".blue")
  console.log(blueCount.length)
  //
const blueCompanies=document.getElementById("blueCompanies")
blueCompanies.textContent=`Number of blueCompanies:${blueCount.length}` 
  //Question 3:add background color and remove 
  function setBackgroundColor(){
 document.body.style.backgroundColor="#99ecff";
  }
  
  function removeBackgroundColor (){
    document.body.style.backgroundColor="";
  }
  const backgroundColorAdd=document.getElementById("yes")
  const backgroundColorRemove=document.getElementById("no")
  backgroundColorAdd.addEventListener("click",setBackgroundColor)
  backgroundColorRemove.addEventListener("click",removeBackgroundColor)
  //Question 4: sum of two number
  const addNumber=document.getElementById("click")
  const result=document.getElementById("result")
  function sumation(event){
    event.preventDefault();
    const x=parseFloat(document.getElementById("x").value)
    const y=parseFloat(document.getElementById("y").value)
    if(!isNaN(x) && !isNaN(y)){
      result.textContent=`${x + y}`;
    }else{
      result.textContent=("please enter numerical number")
    }
  }
  
  addNumber.addEventListener("click",sumation)
